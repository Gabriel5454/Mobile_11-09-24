package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                Surface{
                    val myButtonColors = android.widget.Button(this).apply {
                        Row {
                            setBackgroundColor(Color.Yellow)
                            setTextColor(Color.Black)
                            setPadding(16, 16, 16, 16)
                        }

                    }

                }


                Column {


                    Box{
                        Column {
                            Text(text = "Tarefa 1")
                            Text(text = "Descrição: Fazer seminário da Escola")
                            Text(text = "Dia da Tarefa: 10/09/2024")


                            Row {
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Concluir")

                                }
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Finalizar")

                                }
                            }
                        }
                    }





                    Box {
                        Column {
                            Text(text = "Tarefa 2")
                            Text(text = "Descrição: Encher o estoque de comida")
                            Text(text = "Dia da Tarefa: 11/09/2024")

                            Row {
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Concluir")

                                }
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Finalizar")

                                }

                            }
                        }
                    }





                    Box{
                        Column {
                            Text(text = "Tarefa 3")
                            Text(text = "Descrição: Aula De Bateria")
                            Text(text = "Dia da Tarefa: 11/09/2024")

                            Row {
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Concluir")

                                }
                                Button(onClick = { /*TODO*/ }) {
                                    Text(text = "Finalizar")

                                }
                            }
                        }
                    }
                }

            }
        }
    }

     fun setPadding(i: Int, i1: Int, i2: Int, i3: Int) {
        TODO("Not yet implemented")
    }

    fun setTextColor(black: Color) {

    }

    fun setBackgroundColor(yellow: Color) {

    }


}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MyApplicationTheme {
        Greeting("Android")
    }
}