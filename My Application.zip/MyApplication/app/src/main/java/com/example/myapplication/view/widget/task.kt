package com.example.myapplication.view.widget

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun Teste() {

    Column {


        Box {
            Column {
                Text(text = "Atividade 1")
                Text(text = "Descrição: Fazer seminário da Escola")
                Text(text = "Dia da Tarefa: 10/09/2024")


                Row {
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Concluir")

                    }
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Finalizar")

                    }
                }
            }
        }





        Box {
            Column {
                Text(text = "Atividade 2")
                Text(text = "Descrição: Encher o estoque de comida")
                Text(text = "Dia da Tarefa: 11/09/2024")

                Row {
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Concluir")

                    }
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Finalizar")

                    }

                }
            }
        }





        Box {
            Column {
                Text(text = "Atividade 3")
                Text(text = "Descrição: Aula De Bateria")
                Text(text = "Dia da Tarefa: 11/09/2024")

                Row {
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Concluir")

                    }
                    Button(onClick = { /*TODO*/ }) {
                        Text(text = "Finalizar")

                    }
                }
            }
        }
    }
}