package com.example.myapplication.model

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.LocalDate

class TarefaClass(
    val titulo: String,
    val data: LocalDate,
)
@RequiresApi(Build.VERSION_CODES.O)
val Tarefa1 = TarefaClass(
            titulo = "Atividade 1",
            data = LocalDate.of( 2024,  9, 11)
)
@RequiresApi(Build.VERSION_CODES.O)
val Tarefa2 = TarefaClass(
    titulo = "Atividade 1",
    data = LocalDate.of( 2024,  9,  11)
)
@RequiresApi(Build.VERSION_CODES.O)
val Tarefa3 = TarefaClass(
    titulo = "Atividade 1",
    data = LocalDate.of( 2024,  9, 11)
)



